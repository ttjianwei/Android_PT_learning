package com.example.aidlcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    int result;
    TextView res;
    EditText n1;
    EditText n2;
    Button b1;
    IMyAidlInterface myCalculator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        res = (TextView)findViewById(R.id.textView2);
        n1 = (EditText)findViewById(R.id.editTextTextPersonName);
        n2 = (EditText)findViewById(R.id.editTextTextPersonName2);
        b1 = (Button)findViewById(R.id.button);
        Intent i = new Intent(this,MyService.class);
        bindService(i,mConnection,BIND_AUTO_CREATE);
    }

    public void sample(View view){
        int value1 = Integer.parseInt(n1.getText().toString());
        int value2 = Integer.parseInt(n2.getText().toString());
        try {

            result = myCalculator.addition(value1,value2);
            System.out.println(result);

            res.setText(String.valueOf(result));

        } catch (RemoteException e){
            e.printStackTrace();
        }
    }


    ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            myCalculator=IMyAidlInterface.Stub.asInterface(iBinder);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };
}