package com.example.deeplinking;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Uri uri = getIntent().getData();
        if (uri!=null){
            String path = uri.toString();
            Toast.makeText(MainActivity.this,"Path = " + path,Toast.LENGTH_LONG ).show();

            WebView webView = (WebView) findViewById(R.id.webView);
            webView.loadUrl(path);
        }
    }
}